package com.ly;

import java.awt.Point;
import java.awt.Robot;
import java.awt.event.InputEvent;

public class Main {

	public static void main(String[] args) throws Exception {
//		Thread.sleep(3000);
		Point from = new Point(169, 169+65);
		Robot robot = new Robot();
		/*Point curPoint = MouseUtil.getPoint();
		System.out.println("��ǰλ��:("+curPoint.x+","+curPoint.x+")");
		String reshPoint ="169,169";
		
		Point to = new Point(169, 169+400);
//		MouseUtil.press(from, to);
		
		
		//ת��Ŀ��λ��
		robot.mouseMove(from.x, from.y);
		
		//ˢ��
		robot.mousePress(InputEvent.BUTTON1_MASK);
		for (int i = 1; i < 400; i=i+5) {
//			from.y=from.y+i;
			Thread.sleep(100);
			robot.mouseMove(from.x, from.y+i);
		}
		
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
		
		robot.mouseMove(from.x, 169+65+200);
		Thread.sleep(100);
		robot.mousePress(InputEvent.BUTTON1_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
		*/
//		Thread.sleep(2000);
		//�鿴��Ѷ
		robot.mouseMove(from.x, from.y);
		robot.mousePress(InputEvent.BUTTON1_MASK);
		for (int i = 1; i < 100; i=i+5) {
//			from.y=from.y+i;
			Thread.sleep(100);
			robot.mouseMove(from.x, from.y+i);
			robot.mouseWheel(100);
		}
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
	}
}
