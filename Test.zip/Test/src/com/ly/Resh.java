package com.ly;

import java.awt.AWTException;
import java.awt.Point;
import java.awt.Robot;
import java.awt.event.InputEvent;

public class Resh {

	public static final void resh(Point startBtPoint, Point reshFromPoit,
			int max,double random) throws Exception {
		max=max>0?max:6;
		// ������ҳ
		Robot robot = new Robot();
		robot.mouseMove(startBtPoint.x, startBtPoint.y);
		robot.mousePress(InputEvent.BUTTON1_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_MASK);
		Thread.sleep((int)(3000*random));

		// ˢ��
		// ת��Ŀ��λ��
		robot.mouseMove(reshFromPoit.x, reshFromPoit.y);

		// ˢ��
		robot.mousePress(InputEvent.BUTTON1_MASK);
		for (int i = 1; i < 400; i = i + 5) {
			// from.y=from.y+i;
			Thread.sleep(100);
			robot.mouseMove(reshFromPoit.x, reshFromPoit.y + i);
		}

		robot.mouseMove(reshFromPoit.x, reshFromPoit.y + 400);

		robot.mouseRelease(InputEvent.BUTTON1_MASK);

		Thread.sleep((int)(4000*random));

		robot.mouseMove(reshFromPoit.x, reshFromPoit.y + 200);
		Thread.sleep(100);
		robot.mousePress(InputEvent.BUTTON1_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_MASK);

		// ������ʽҳ��

		Thread.sleep((int)(5000*random));

		// �鿴��Ѷ
		robot.mouseMove(reshFromPoit.x, reshFromPoit.y);
		robot.mousePress(InputEvent.BUTTON1_MASK);
		int count = 0;
		while (count < max) {
			Thread.sleep(100);
			for (int i = 1; i < 100; i = i + 5) {

				Thread.sleep(100);
				robot.mouseMove(reshFromPoit.x, reshFromPoit.y + i);
				robot.mouseWheel(100);
			}
			for (int i = 100; i > 1; i = i - 5) {

				Thread.sleep(100);
				robot.mouseMove(reshFromPoit.x, reshFromPoit.y + i);
				robot.mouseWheel(100);
			}
			count++;
		}

		robot.mouseRelease(InputEvent.BUTTON1_MASK);

		// robot.mouseMove(reshFromPoit.x, reshFromPoit.y);
		// robot.mousePress(InputEvent.BUTTON1_MASK);
		// for (int i = 1; i < 100; i=i+5) {
		//
		// Thread.sleep(100);
		// robot.mouseMove(reshFromPoit.x, reshFromPoit.y+i);
		// robot.mouseWheel(100);
		// }
		// robot.mouseRelease(InputEvent.BUTTON1_MASK);
	}

	public static void main(String[] args) throws Exception {

		Point startBtPoint = new Point(19, 65);
		Point reshFromPoit = new Point(169, 169 + 65);
		while (true) {
			int sleep = (int) ((int)(Math.random()*10) * 5);// �漴һ��0-5������
			Thread.sleep(sleep);
			resh(startBtPoint, reshFromPoit, (int) ((int)(Math.random()) * 20),(int)(Math.random()*5));
		}

	}
}
