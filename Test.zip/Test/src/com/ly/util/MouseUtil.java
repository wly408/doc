package com.ly.util;

import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.InputEvent;

import com.ly.bean.ColorBean;
import com.ly.bean.PointBean;

public class MouseUtil {
	/**
	 * ���������λ��
	 * @param point
	 */
	public static void click(PointBean point){
		move(point);
		click();
	}
	/**
	 * �����
	 */
	public static void click(){
		RobotInstance.getRobot().mousePress(InputEvent.BUTTON1_MASK);
		RobotInstance.getRobot().mouseRelease(InputEvent.BUTTON1_MASK);
		
	}
	/**
	 * ����ƶ�������λ��
	 * @param point
	 */
	public static void move(PointBean point) {
		RobotInstance.getRobot().delay(1000);
		System.out.println("����ƶ���:"+point);
		RobotInstance.getRobot().mouseMove(point.x,point.y);
	}
	public static PointBean getCurrentPoint(){
		PointerInfo pinfo = MouseInfo.getPointerInfo();
		Point p = pinfo.getLocation();
		double mx = p.getX();
		double my = p.getY();
		PointBean point = new PointBean();
		point.x=(int)mx;
		point.y=(int)my;
		System.out.println("��굱ǰλ��:"+point);
		return point;
	}
	/**
	 *  ������
	 * @param from ��ʼλ��
	 * @param wheel ���ִ���
	 */
	public static void wheel(PointBean from,int wheel){
		move(from);
		System.out.println("������ǰλ��:"+getCurrentPoint());
		RobotInstance.getRobot().mousePress(InputEvent.BUTTON1_MASK);
//		for (int i = 1; i < 2; i=i+5) {
////			from.y=from.y+i;
//			try {
//				Thread.sleep(100);
//			} catch (InterruptedException e) {
//				
//				e.printStackTrace();
//			}
////			RobotInstance.getRobot().mouseMove(from.x, from.y+i);
//			RobotInstance.getRobot().mouseWheel(100);
//		}
		RobotInstance.getRobot().mouseWheel(wheel);
		RobotInstance.getRobot().mouseRelease(InputEvent.BUTTON1_MASK);
		System.out.println("�����ֺ�λ��:"+getCurrentPoint());
	}
	public static void dragDown(PointBean from,PointBean to){
		move(from);
		System.out.println("����϶�ǰλ��:"+getCurrentPoint());
		RobotInstance.getRobot().mousePress(InputEvent.BUTTON1_MASK);
		int max = to.y;
		for (int i = 0; i < 1000000; i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			if(from.y+i>max){
				break;
			}
			
			RobotInstance.getRobot().mouseMove(from.x, from.y+i);

		}

		RobotInstance.getRobot().mouseRelease(InputEvent.BUTTON1_MASK);
		System.out.println("����϶���λ��:"+getCurrentPoint());
	}
	public static void dragTimes(PointBean from,PointBean to,int times){
		for (int i = 0; i < times; i++) {
			NumUtil.sleep(NumUtil.random(1, 5)*1000);
			dragDown(from, to);
			dragUp(to, from);
		}
	}
	public static void dragUp(PointBean from,PointBean to){
		move(from);
		System.out.println("����϶�ǰλ��:"+getCurrentPoint());
		RobotInstance.getRobot().mousePress(InputEvent.BUTTON1_MASK);
		int min = to.y;
		for (int i = 0; i < 1000000; i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			if(from.y-i<min){
				break;
			}
			
			RobotInstance.getRobot().mouseMove(from.x, from.y-i);
			
		}

		
		RobotInstance.getRobot().mouseRelease(InputEvent.BUTTON1_MASK);
		System.out.println("����϶���λ��:"+getCurrentPoint());
	}
	public static ColorBean getColor(PointBean point){
		Color co = RobotInstance.getRobot().getPixelColor(point.x,point.y);
		return new ColorBean(co.getRed(),co.getGreen(),co.getBlue());
	}
	
	public static void main(String[] args)throws Exception {
		Thread.sleep(3000);
		PointBean point = getCurrentPoint();//(387,271)

		point.x=387;
		point.y=271;
//		move(point);
//		wheel(point,2);
		PointBean to = new PointBean(point.x,point.y+100);
//		dragTimes(point, to, 5);
		
	}
	public static void stopApp(PointBean stopPoint){
		NumUtil.sleep(NumUtil.random(1, 4));
		click(stopPoint);
		NumUtil.sleep(NumUtil.random(10, 15));

	}
	public static void startApp(PointBean startPoint){
		NumUtil.sleep(NumUtil.random(1, 4));
		click(startPoint);
		NumUtil.sleep(NumUtil.random(10, 15));

	}

	
	
}
