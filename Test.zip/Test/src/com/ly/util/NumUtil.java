package com.ly.util;

import java.util.Random;

public final class NumUtil {

	public static int random(int start,int end){
		Random rand = new Random();
		return rand.nextInt(end-start+1)+ start;
	}
	public static void main(String[] args) {
		for (int i = 0; i < 20; i++) {
			System.out.println(random(5,10));
		}

	}
	public static void sleep(long times){
		try {
			Thread.sleep(times);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
