package com.ly.util;

import java.awt.AWTException;
import java.awt.Robot;


public class RobotInstance {
	
	public static Robot robo;
	private final static Object key = new Object();
	
	public static Robot getRobot(){
		synchronized (key) {
			if(robo==null){
				try {
					robo = new Robot();
				} catch (AWTException e) {

					e.printStackTrace();
				}
			}
			return robo;
		}
		
	}

}
