package com.ly;

import java.awt.Point;
import java.awt.Robot;
import java.awt.event.InputEvent;

public class MouseUtil {
	
	public static void move(int x,int y) throws Exception{
		Robot robot = new Robot();
		 robot.mouseMove(x,y);
		
	}
	public static void press(Point from,Point to)throws Exception{
		Robot robot = new Robot();
		robot.mouseMove(from.x, from.y);
        
        robot.mousePress(InputEvent.BUTTON1_MASK);
        
        robot.mouseMove(to.x, to.y);
       
        robot.mousePress(InputEvent.BUTTON1_MASK);
	}
	public static Point getPoint(){
		Point point = java.awt.MouseInfo.getPointerInfo().getLocation();
		
		return point;
	}
	public static void main(String[] args) throws Exception {
		Thread.sleep(8000);
		int count = 0;
		Point from = getPoint();
		Point to = new Point();
		to.x=from.x;
		to.y=from.y+50;
		while(count<10){
			System.out.println("��("+from.x+","+from.y+")��"+"("+to.x+","+to.y+")");
			press(from, to);
			Thread.sleep(2000);
			System.out.println("��("+to.x+","+to.y+")����"+"("+from.x+","+from.y+")");
			press(to, from);
			count++;
		}
		
		
	
		
	}
}
