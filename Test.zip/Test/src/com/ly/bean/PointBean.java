package com.ly.bean;

public class PointBean {

	public int x;
	public int y;
	public PointBean() {
	
	}
	
	public PointBean(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}


	@Override
	public String toString() {
		StringBuffer content = new StringBuffer();
		content.append("(").append(x).append(",").append(y).append(")");
		return content.toString();
	}
	
	
}
