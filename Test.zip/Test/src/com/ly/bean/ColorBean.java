package com.ly.bean;

public class ColorBean {
	public int red;
	public int green;
	public int blue;
	public ColorBean() {
		
	}
	
	public ColorBean(int red, int green, int blue) {
		super();
		this.red = red;
		this.green = green;
		this.blue = blue;
	}


	@Override
	public String toString() {
		StringBuffer content = new StringBuffer();
		content.append("(").append(red).append(",").append(green).append(",").append(blue).append(")");
		return content.toString();
	}

	
}
