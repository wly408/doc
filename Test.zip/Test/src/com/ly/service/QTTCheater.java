package com.ly.service;

import com.ly.bean.PointBean;
import com.ly.util.MouseUtil;
import com.ly.util.NumUtil;

public class QTTCheater extends ABCheater{

	public QTTCheater(int cheatCount, int cheatMax, int reStartCount) {
		super(cheatCount, cheatMax, reStartCount);
	}

	@Override
	public void startApp() {
		PointBean startPoint = new PointBean();
		NumUtil.sleep(NumUtil.random(1, 4));
		MouseUtil.click(startPoint);
		NumUtil.sleep(NumUtil.random(10, 15));
	}

	@Override
	public void toIndex() {
		PointBean indexPoint = new PointBean();
		MouseUtil.click(indexPoint);
		NumUtil.sleep(NumUtil.random(5,8));
		
		//ˢ��
		PointBean from = new PointBean();
		PointBean to = new PointBean();
		MouseUtil.dragDown(from, to);
		NumUtil.sleep(NumUtil.random(5, 8));
		
	}

	@Override
	public void clickAdv() {
		PointBean advPoint = new PointBean();
		MouseUtil.click(advPoint);
		NumUtil.sleep(NumUtil.random(5,8));
		
	}

	@Override
	public void browseAdv() {
		PointBean from = new PointBean();
		MouseUtil.wheel(from, 5);
		NumUtil.sleep(NumUtil.random(2,3));
		MouseUtil.wheel(MouseUtil.getCurrentPoint(), -5);
	}

	@Override
	public void stopApp() {
		PointBean stopPoint = new PointBean();
		NumUtil.sleep(NumUtil.random(1, 4));
		MouseUtil.click(stopPoint);
		NumUtil.sleep(NumUtil.random(10, 15));
	}

}
