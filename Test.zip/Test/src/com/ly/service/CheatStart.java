package com.ly.service;


public class CheatStart {

	
	public static void run(){
		
		
		
	}
}
