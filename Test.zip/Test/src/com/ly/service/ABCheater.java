package com.ly.service;




public abstract class ABCheater {
	
	private int cheatCount;
	private int cheatMax;
	private int reStartCount;
	
	
	public ABCheater(int cheatCount, int cheatMax, int reStartCount) {
		super();
		this.cheatCount = cheatCount;
		this.cheatMax = cheatMax;
		this.reStartCount = reStartCount;
	}

	public abstract void startApp();
	
	public abstract void stopApp();
	
	public abstract void toIndex();
	
	public abstract void clickAdv();
	
	public abstract void browseAdv();

	
	

	public void run(){
		while(cheatMax<cheatCount){
			
			if(cheatCount>0&&cheatCount%reStartCount==0){
				this.stopApp();
				this.startApp();
			}
			this.toIndex();
			this.clickAdv();
			this.browseAdv();
			this.cheatCount++;
			
		}
		
	}

}
